Features:
Create the first Roku app which just shows the text "Hello world!".
